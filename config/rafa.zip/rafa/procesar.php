<?php
$conexion = new mysqli("localhost", "root", "", "dulces");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$accion = $_POST['accion'];
$nombre = trim($_POST['nombre']);
$contraseña = md5($_POST['contraseña']); // Usamos md5 directamente

// Verificar si el usuario ya existe
$sql_check = "SELECT * FROM usuario WHERE nombre = ?";
$stmt_check = $conexion->prepare($sql_check);
$stmt_check->bind_param("s", $nombre);
$stmt_check->execute();
$result = $stmt_check->get_result();
$usuario_existe = $result->fetch_assoc();

if ($accion == "registro") {
    if ($usuario_existe) {
        echo "<p>❌ El usuario ya existe. Intenta iniciar sesión.</p>";
    } else {
        $insert_sql = "INSERT INTO usuario (id, nombre, contraseña) VALUES (NULL, ?, ?)";
        $stmt_insert = $conexion->prepare($insert_sql);
        $stmt_insert->bind_param( $nombre, $contraseña);
        if ($stmt_insert->execute()) {
            echo "<p>✅ Usuario registrado con éxito. Ahora puedes iniciar sesión.</p>";
        } else {
            echo "<p>Error al registrar: " . $stmt_insert->error . "</p>";
        }
    }
} elseif ($accion == "login") {
    if (!$usuario_existe) {
        echo "<p>❌ Usuario no encontrado. Regístrate primero.</p>";
    } else {
        if ($contraseña === $usuario_existe['contraseña']) {
            echo "<h3>✅ Bienvenido a la tienda de dulces, " . htmlspecialchars($usuario_existe['nombre']) . " 🍬</h3>";
        } else {
            echo "<p>❌ Contraseña incorrecta.</p>";
        }
    }
}

$conexion->close();
?>