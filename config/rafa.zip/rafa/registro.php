<?php
$conexion = new mysqli("localhost", "root", "", "dulces");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

$nombre = $_POST['nombre'];
$contraseña = password_hash($_POST['contraseña'], PASSWORD_DEFAULT);

// Insertar usuario
$sql = "INSERT INTO usuario (id, nombre, contraseña) VALUES (NULL, ?, ?)";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("ss", $nombre, $contraseña);
if ($stmt->execute()) {
    echo "✅ Usuario registrado exitosamente.";
} else {
    echo "❌ Error: " . $stmt->error;
}

$stmt->close();
$conexion->close();
?>